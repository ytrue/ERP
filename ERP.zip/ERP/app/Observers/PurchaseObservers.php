<?php
/**
 * Created by PhpStorm.
 * User: 阳毅
 * Date: 2019/2/15
 * Time: 19:37
 */

namespace App\Observers;


use App\Models\Purchase;
use Illuminate\Support\Facades\DB;

class PurchaseObservers
{

}
